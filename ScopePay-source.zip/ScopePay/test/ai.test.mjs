import test from 'node:test';
import assert from 'node:assert/strict';
import {analyse} from '../src/ai.mjs';
test('real local neural model matches paraphrases to catalog without cloud generation',async()=>{
  const r=await analyse('Build a responsive landing page for my piano studio. Let students reserve appointments through a scheduling calendar. Measure visits and lesson signup conversions with website analytics.');
  const ids=r.suggestions.map(s=>s.id);assert.ok(ids.includes('landing'));assert.ok(ids.includes('booking'));assert.ok(ids.includes('analytics'));assert.ok(!ids.includes('brand'));assert.ok(!ids.includes('accessibility'));assert.ok(r.suggestions.every(s=>s.quantity===1&&s.evidence));
});
test('short invalid briefs fail before inference',async()=>{await assert.rejects(analyse('hello'));});
