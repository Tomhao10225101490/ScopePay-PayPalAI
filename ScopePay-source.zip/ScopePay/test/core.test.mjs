import test from 'node:test';
import assert from 'node:assert/strict';
import {quoteFromItems,money} from '../src/catalog.mjs';
import {verifiedReceipt} from '../src/paypal.mjs';
test('catalog prices are server-owned and integer quantities determine totals',()=>{
  const q=quoteFromItems([{id:'landing',quantity:2,price:1},{id:'booking',quantity:1}]);
  assert.equal(q.total,64500);assert.equal(q.currency,'USD');assert.equal(money(q.total),'645.00');
});
test('invalid, duplicate, fractional and negative quantities cannot reach checkout',()=>{
  for(const lines of [[],[{id:'none',quantity:1}],[{id:'copy',quantity:0}],[{id:'copy',quantity:-1}],[{id:'copy',quantity:1.5}],[{id:'copy',quantity:11}],[{id:'copy',quantity:1},{id:'copy',quantity:1}]])assert.throws(()=>quoteFromItems(lines));
});
const quote=quoteFromItems([{id:'landing',quantity:1}]);
const order=()=>({id:'TEST-ORDER',status:'COMPLETED',purchase_units:[{custom_id:'proposal-1',payments:{captures:[{id:'TEST-CAPTURE',status:'COMPLETED',amount:{currency_code:'USD',value:'280.00'},create_time:'2026-11-08T15:00:00Z'}]}}]});
test('completed capture must match reference, currency and exact amount',()=>{
  assert.equal(verifiedReceipt(order(),quote,'proposal-1').captureId,'TEST-CAPTURE');
  for(const change of [o=>o.status='APPROVED',o=>o.purchase_units[0].custom_id='another-proposal',o=>o.purchase_units[0].payments.captures[0].status='PENDING',o=>o.purchase_units[0].payments.captures[0].amount.value='1.00',o=>o.purchase_units[0].payments.captures[0].amount.currency_code='EUR',o=>o.purchase_units[0].payments.captures.push({...o.purchase_units[0].payments.captures[0]})]){const o=order();change(o);assert.throws(()=>verifiedReceipt(o,quote,'proposal-1'));}
});
