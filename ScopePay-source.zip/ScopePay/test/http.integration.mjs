import assert from 'node:assert/strict';
const base=process.env.TEST_URL||'http://localhost:4317';
async function client(){
  const initial=await fetch(base+'/api/state');const state=await initial.json();const cookie=initial.headers.get('set-cookie').split(';')[0];
  return {state,async post(path,input,extra={}){const res=await fetch(base+'/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',Origin:base,Cookie:cookie,'X-CSRF-Token':state.csrf,...extra},body:JSON.stringify(input)});return {status:res.status,body:await res.json()};}};
}
const a=await client(),b=await client();
assert.notEqual(a.state.csrf,b.state.csrf);
assert.equal((await a.post('proposals',{},{Origin:'https://untrusted.example'})).status,403);
assert.equal((await a.post('proposals',{}, {'X-CSRF-Token':'wrong'})).status,403);
assert.equal((await a.post('proposals',{title:'Unreviewed',scope:'test',items:[{id:'copy',quantity:1}],confirmed:false})).status,400);
const result=await a.post('proposals',{title:'Integration test',scope:'Synthetic test data',items:[{id:'landing',quantity:1,price:1},{id:'booking',quantity:2}],confirmed:true});
assert.equal(result.status,201);assert.equal(result.body.proposal.quote.total,45000);
assert.equal((await b.post('orders',{proposalId:result.body.proposal.id})).status,400);
assert.equal((await b.post('reconcile',{orderId:'not-owned'})).status,400);
assert.equal((await a.post('proposals',{title:'Invalid quantity',scope:'test',items:[{id:'copy',quantity:-3}],confirmed:true})).status,400);
console.log('PASS: HTTP origin/CSRF enforcement, per-browser workspace isolation, review required, server-owned pricing, invalid quantity rejection. No PayPal payment created by this test.');
