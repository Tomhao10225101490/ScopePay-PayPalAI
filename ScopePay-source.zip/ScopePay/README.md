# ScopePay

**Clear scope. Confident checkout.** An AI-assisted service proposal workspace for independent professionals, built for the PayPal AI Hackathon 2026.

A client brief becomes an evidence-linked shortlist from a six-service catalog. A person reviews the items, quantities and deliverables. The server saves an immutable proposal snapshot, creates a real PayPal sandbox order, and verifies the approved capture against that proposal before issuing a test receipt.

## Run the functional application

1. Install Node.js 22 or newer.
2. Clone/download this repository, enter its root, and run `npm ci`.
3. Copy `.env.example` to `.env`.
4. In the official [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/applications/sandbox), sign in to your own PayPal developer account and select **Sandbox**. Use a sandbox REST application's client ID and secret in `.env`. Do not use live credentials.
5. Run `npm run warmup`. The first run downloads the quantized `Xenova/all-MiniLM-L6-v2` model and tokenizer into ignored `.cache/`; it requires internet access. Inference is local thereafter.
6. Run `npm start`, then open **http://localhost:4317** in Chrome. Keep the server running during checkout so PayPal can redirect to localhost.
7. Build a draft from the example brief. It should suggest landing page, booking and analytics services. Review everything, leave quantities at one, and save the proposal (**$430.00 USD test total**).
8. Create the PayPal sandbox checkout. Open it and approve with a **personal sandbox buyer**, not the merchant account. Obtain your own test buyer credentials from [Sandbox accounts](https://developer.paypal.com/dashboard/accounts); these are simulated accounts and no real funds move.
9. Return to ScopePay and click **Verify & capture approved order**. Only a completed capture with the matching proposal reference, currency and exact amount produces a verified receipt. Download its JSON or reopen the proposal from the workspace.

No shared credentials are necessary or published. Judges can obtain their own free sandbox credentials using the instructions above. If 4317 is occupied, update both `PORT` and `APP_URL` to the same local port. The server intentionally binds loopback and supports **sandbox only**.

## AI, accurately described

Transformers.js runs a quantized MiniLM sentence embedding model through ONNX Runtime on the local CPU. Cosine similarity matches each sentence to the nearest catalog service with a threshold. The UI shows the source sentence and score; that score is **not a probability**. This is semantic retrieval, not generative AI or automatic contract interpretation. It can miss multiple requirements in one sentence, misunderstood negations or unusual requests. Edit the selected services rather than treating suggestions as authoritative.

Quantities, prices, deadlines and acceptance are not inferred by AI. Catalog prices are illustrative. A saved scope uses the original brief and selected catalog deliverables. General questions about supplied materials, deadlines and acceptance are fixed review prompts, not model-generated advice.

## PayPal is central

- Server-side OAuth2 uses credentials only in `.env`.
- Orders v2 creates an itemized CAPTURE-intent sandbox order from server-priced proposal data.
- Persisted `PayPal-Request-Id` values protect order-create retries and capture retries.
- Payer approval happens on PayPal's sandbox site.
- Reconciliation fetches the order, captures only if APPROVED, and verifies COMPLETED status, proposal reference, currency and exact captured amount.
- A browser return URL alone never marks an order paid. Cancelled/pending orders have no paid receipt.
- Receipts and workspace records persist locally under ignored `data/`; HttpOnly random session cookies separate browser workspaces. Mutations check Origin and a session CSRF token.

This is a single-computer prototype, not a production multi-tenant service. It has no customer sharing/authentication system, signed contract, tax calculation, refunds, disputes, webhook listener or unattended settlement. Payment status is refreshed on explicit verification, not by webhook. No live endpoint can be enabled by changing an environment variable.

## Verification

`npm test` runs real local-model matching tests and unit cases for price/quantity rules and capture/reference/amount validation. With `npm start` running, `node test/http.integration.mjs` checks CSRF/origin enforcement, per-browser ownership and server pricing. See `VERIFICATION.md` for the actual completed browser and sandbox checks; do not interpret unit fixtures as live payment evidence.

## Provenance

The original application, design, code, copy and tests were created during the submission period. AI coding assistance helped plan, implement, debug and document this project. The participant requested end-to-end execution and provided their own account login; no real client data is used in the example.

The MIT license applies to original project source. Third-party dependencies retain their own licenses: Transformers.js and MiniLM model materials use Apache-2.0; ONNX Runtime uses MIT. [Model card](https://huggingface.co/Xenova/all-MiniLM-L6-v2), [Transformers.js](https://huggingface.co/docs/transformers.js/). UI typography loads Google Fonts (Manrope and DM Sans, SIL Open Font License), with local system fallback. No third-party music or stock illustration is included. PayPal marks appear only in the official service flow or descriptive integration text.

Development/recording uses the existing local Node, Python, Pillow and FFmpeg environment. No earlier hackathon app code is submitted as ScopePay. Demo narration, if synthetic, is labeled in the video description and media notes.
