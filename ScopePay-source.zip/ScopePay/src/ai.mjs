import {pipeline,env} from '@huggingface/transformers';
import {fileURLToPath} from 'node:url';
import {catalog} from './catalog.mjs';
env.cacheDir=fileURLToPath(new URL('../.cache/models/',import.meta.url));
let extractorPromise, catalogVectors;
export const MODEL='Xenova/all-MiniLM-L6-v2';
export async function ready() {
  extractorPromise ??= pipeline('feature-extraction',MODEL,{dtype:'q8',device:'cpu'}).catch(e=>{extractorPromise=null;throw e;});
  const extractor=await extractorPromise;
  catalogVectors ??= await extractor(catalog.map(s=>s.description),{pooling:'mean',normalize:true});
  return extractor;
}
export async function analyse(brief) {
  if(typeof brief!=='string'||brief.trim().length<20||brief.length>4000) throw new Error('Describe the work in 20–4000 characters.');
  const extractor=await ready();
  const sentences=brief.split(/[\n.!?;]+/).map(s=>s.trim()).filter(s=>s.length>8).slice(0,24);
  const vectors=await extractor(sentences,{pooling:'mean',normalize:true});
  const width=vectors.dims[1];
  const suggestions=catalog.map((service,i)=>{
    let best=-1,evidence='';
    for(let j=0;j<sentences.length;j++) {
      let dot=0;for(let k=0;k<width;k++)dot+=catalogVectors.data[i*width+k]*vectors.data[j*width+k];
      if(dot>best){best=dot;evidence=sentences[j];}
    }
    return {id:service.id,similarity:Number(best.toFixed(3)),evidence,quantity:1};
  }).filter(s=>s.similarity>=0.30).filter(s=>{
    // A broad shared word such as "website" must not select every related service.
    // Keep a service only when it is the closest semantic match for a sentence.
    const sentenceIndex=sentences.indexOf(s.evidence);
    let winner=0,best=-1;
    for(let i=0;i<catalog.length;i++){
      let dot=0;for(let k=0;k<width;k++)dot+=catalogVectors.data[i*width+k]*vectors.data[sentenceIndex*width+k];
      if(dot>best){best=dot;winner=i;}
    }
    return catalog[winner].id===s.id;
  }).sort((a,b)=>b.similarity-a.similarity).slice(0,4);
  return {model:MODEL,method:'Local neural sentence embeddings and cosine similarity',suggestions,questions:[
    'Who supplies the content, images and account access?',
    'What delivery date and revision deadline can both sides accept?',
    'Which items and acceptance criteria should be included or excluded?'
  ],notice:'AI matches meaning to an illustrative fixed-price catalog. It does not negotiate, infer quantities, promise a delivery date or decide the charge. Review every match.'};
}
if(process.argv[1]===fileURLToPath(import.meta.url)) {
  console.log(JSON.stringify(await analyse('I teach piano and need a mobile friendly landing page. Add a calendar so students can book a lesson. Also set up analytics to track signups.'),null,2));
}
