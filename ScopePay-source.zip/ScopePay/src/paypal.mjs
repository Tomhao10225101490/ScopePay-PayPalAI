import {money} from './catalog.mjs';
const BASE='https://api-m.sandbox.paypal.com';
let cachedToken, expires=0;
export const configured=()=>Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);
async function token() {
  if(cachedToken&&Date.now()<expires)return cachedToken;
  if(!configured())throw new Error('PayPal sandbox credentials are not configured.');
  const res=await fetch(`${BASE}/v1/oauth2/token`,{method:'POST',headers:{Authorization:`Basic ${Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials',signal:AbortSignal.timeout(20000)});
  const body=await res.json();if(!res.ok)throw new Error('PayPal sandbox authentication failed.');
  cachedToken=body.access_token;expires=Date.now()+(body.expires_in-60)*1000;return cachedToken;
}
async function request(path,{method='GET',body,key}={}) {
  const res=await fetch(BASE+path,{method,headers:{Authorization:`Bearer ${await token()}`,'Content-Type':'application/json',Prefer:'return=representation',...(key?{'PayPal-Request-Id':key}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(25000)});
  const data=await res.json();if(!res.ok) {const e=new Error(`PayPal sandbox request failed (${data.name||res.status}). Retry or inspect your sandbox logs.`);e.debugId=data.debug_id;throw e;}return data;
}
export async function createOrder(quote,reference,key,appUrl) {
  return request('/v2/checkout/orders',{method:'POST',key,body:{intent:'CAPTURE',purchase_units:[{reference_id:reference,custom_id:reference,description:'ScopePay reviewed service proposal — sandbox demo',amount:{currency_code:quote.currency,value:money(quote.total),breakdown:{item_total:{currency_code:quote.currency,value:money(quote.total)}}},items:quote.lines.map(l=>({name:l.name,quantity:String(l.quantity),unit_amount:{currency_code:quote.currency,value:money(l.price)},category:'DIGITAL_GOODS'}))}],payment_source:{paypal:{experience_context:{brand_name:'ScopePay Sandbox',shipping_preference:'NO_SHIPPING',user_action:'PAY_NOW',return_url:`${appUrl}/?checkout=returned`,cancel_url:`${appUrl}/?checkout=cancelled`}}}}});
}
export const getOrder=id=>request(`/v2/checkout/orders/${encodeURIComponent(id)}`);
export const captureOrder=(id,key)=>request(`/v2/checkout/orders/${encodeURIComponent(id)}/capture`,{method:'POST',key,body:{}});
export function verifiedReceipt(order,quote,reference) {
  if(order.status!=='COMPLETED')throw new Error('Payment is not completed. No paid receipt was issued.');
  const units=order.purchase_units||[];
  if(units.length!==1 || units[0].custom_id!==reference)throw new Error('Payment reference did not match this proposal.');
  const captures=units[0].payments?.captures||[];
  if(captures.length!==1)throw new Error('Unexpected capture data.');
  const c=captures[0];
  if(c.status!=='COMPLETED'||c.amount?.currency_code!==quote.currency||c.amount?.value!==money(quote.total)) throw new Error('Capture amount or status did not match the reviewed proposal.');
  return {orderId:order.id,captureId:c.id,status:c.status,currency:quote.currency,total:quote.total,paidAt:c.create_time,verifiedAt:new Date().toISOString(),environment:'sandbox'};
}
