export const catalog = [
  {id:'landing', name:'Landing page', price:28000, unit:'page', description:'Design and build a single responsive marketing landing page for a product, event or small business.', deliverable:'One responsive page, desktop and mobile layouts, one revision round.'},
  {id:'copy', name:'Website copy', price:9000, unit:'page', description:'Write or rewrite clear website text, headlines, product descriptions and a call to action.', deliverable:'Up to 600 words, headline options, one revision round.'},
  {id:'analytics', name:'Analytics setup', price:6500, unit:'setup', description:'Install website analytics, measure visits, conversions and signups, configure tracking events.', deliverable:'One analytics property and up to three conversion events; client supplies account access.'},
  {id:'accessibility', name:'Accessibility review', price:12000, unit:'review', description:'Review a website for accessibility, keyboard navigation, contrast, screen reader issues and inclusive design.', deliverable:'Review of one page, prioritized issue report and keyboard walkthrough; no certification.'},
  {id:'booking', name:'Booking integration', price:8500, unit:'setup', description:'Add an appointment scheduling calendar or booking form so visitors can reserve a lesson or consultation.', deliverable:'One existing scheduling provider embedded and tested; provider fees excluded.'},
  {id:'brand', name:'Visual identity kit', price:16000, unit:'kit', description:'Create a simple logo, color palette, typography and basic brand identity for a small business.', deliverable:'One simple identity direction, color/type notes and export files, one revision round.'}
];
export function quoteFromItems(items) {
  if (!Array.isArray(items) || !items.length || items.length>12) throw new Error('Choose at least one service (maximum 12).');
  const seen=new Set();
  const lines=items.map(({id,quantity})=>{
    const service=catalog.find(s=>s.id===id);
    if(!service || seen.has(id) || !Number.isInteger(quantity) || quantity<1 || quantity>10) throw new Error('Invalid service or quantity.');
    seen.add(id);
    return {...service,quantity,total:service.price*quantity};
  });
  return {currency:'USD',lines,total:lines.reduce((s,l)=>s+l.total,0)};
}
export const money=cents=>(cents/100).toFixed(2);
