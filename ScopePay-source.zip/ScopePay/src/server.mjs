import http from 'node:http';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {randomBytes,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {catalog,quoteFromItems} from './catalog.mjs';
import {analyse,MODEL} from './ai.mjs';
import {configured,createOrder,getOrder,captureOrder,verifiedReceipt} from './paypal.mjs';
const port=Number(process.env.PORT||4317);
const appUrl=process.env.APP_URL||`http://localhost:${port}`;
const dataDir=new URL('../data/',import.meta.url);
await mkdir(dataDir,{recursive:true,mode:0o700});
const sessions=new Map();
const inFlight=new Set();
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data,(key,value)=>['captureKey','orderRequestId'].includes(key)?undefined:value));};
async function save(session){const dest=new URL(session.id+'.json',dataDir);const tmp=new URL(session.id+'.tmp',dataDir);await writeFile(tmp,JSON.stringify(session),{mode:0o600});await rename(tmp,dest);}
async function getSession(req,res){
  let id=req.headers.cookie?.match(/(?:^|;\s*)scopepay=([a-f0-9]{48})(?:;|$)/)?.[1];
  if(id&&!sessions.has(id)){try{const s=JSON.parse(await readFile(new URL(id+'.json',dataDir),'utf8'));if(s.id===id)sessions.set(id,s);}catch{}}
  if(!id||!sessions.has(id)){id=randomBytes(24).toString('hex');sessions.set(id,{id,csrf:randomBytes(24).toString('hex'),proposals:[],orders:[]});res.setHeader('Set-Cookie',`scopepay=${id}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${appUrl.startsWith('https:')?'; Secure':''}`);}
  return sessions.get(id);
}
async function body(req){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>18000)throw new Error('Request too large.');}return JSON.parse(raw||'{}');}
const safeSession=s=>({proposals:s.proposals,orders:s.orders});
const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');
  try{
    const url=new URL(req.url,appUrl);
    if(![new URL(appUrl).host,`localhost:${port}`,`127.0.0.1:${port}`].includes(req.headers.host))return json(res,403,{error:'Host not allowed.'});
    if(!url.pathname.startsWith('/api/')){
      const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css'};
      if(!files[url.pathname]){res.writeHead(404);return res.end('Not found');}
      const bytes=await readFile(new URL('../public/'+files[url.pathname],import.meta.url));
      res.writeHead(200,{'Content-Type':url.pathname.endsWith('.js')?'text/javascript':url.pathname.endsWith('.css')?'text/css':'text/html','Cache-Control':'no-cache'});return res.end(bytes);
    }
    const session=await getSession(req,res);
    if(req.method==='POST'){
      if(req.headers.origin!==new URL(appUrl).origin||req.headers['x-csrf-token']!==session.csrf)return json(res,403,{error:'Reload the app before making changes.'});
      if(inFlight.has(session.id))return json(res,409,{error:'Another action is in progress. Please wait.'});
      inFlight.add(session.id);
    }
    try{
      if(req.method==='GET'&&url.pathname==='/api/state')return json(res,200,{csrf:session.csrf,catalog,model:MODEL,paypalConfigured:configured(),environment:'sandbox',...safeSession(session)});
      if(req.method==='POST'&&url.pathname==='/api/analyse')return json(res,200,await analyse((await body(req)).brief));
      if(req.method==='POST'&&url.pathname==='/api/proposals'){
        const input=await body(req);const quote=quoteFromItems(input.items);
        if(input.confirmed!==true)throw new Error('Review and confirm the scope first.');
        if(typeof input.title!=='string'||!input.title.trim()||input.title.length>100)throw new Error('Add a short proposal title.');
        if(typeof input.scope!=='string'||input.scope.length>5000)throw new Error('Invalid scope.');
        const proposal={id:randomUUID(),title:input.title.trim(),scope:input.scope,quote,createdAt:new Date().toISOString(),reviewed:true};
        session.proposals.unshift(proposal);session.proposals=session.proposals.slice(0,30);await save(session);return json(res,201,{proposal});
      }
      if(req.method==='POST'&&url.pathname==='/api/orders'){
        const input=await body(req);const proposal=session.proposals.find(p=>p.id===input.proposalId);if(!proposal)throw new Error('Proposal not found in your workspace.');
        const existing=session.orders.find(o=>o.proposalId===proposal.id);
        if(existing)return json(res,200,{order:existing});
        // Persist before the request: a timed-out response can safely reuse the same key.
        proposal.orderRequestId ??= randomUUID();await save(session);
        const result=await createOrder(proposal.quote,proposal.id,proposal.orderRequestId,appUrl);
        const approveUrl=result.links?.find(l=>l.rel==='payer-action'||l.rel==='approve')?.href;
        if(!approveUrl||new URL(approveUrl).hostname!=='www.sandbox.paypal.com')throw new Error('PayPal returned an unexpected approval address.');
        const order={id:result.id,proposalId:proposal.id,title:proposal.title,quote:proposal.quote,status:result.status,approveUrl,captureKey:randomUUID(),createdAt:new Date().toISOString()};
        session.orders.unshift(order);await save(session);return json(res,201,{order});
      }
      if(req.method==='POST'&&url.pathname==='/api/reconcile'){
        const input=await body(req);const order=session.orders.find(o=>o.id===input.orderId);if(!order)throw new Error('Order not found in your workspace.');
        if(order.receipt)return json(res,200,{order});
        let remote=await getOrder(order.id);
        if(remote.status==='APPROVED')remote=await captureOrder(order.id,order.captureKey);
        if(remote.status==='COMPLETED'){order.receipt=verifiedReceipt(remote,order.quote,order.proposalId);order.status='COMPLETED';}
        else order.status=remote.status;
        await save(session);return json(res,200,{order});
      }
      return json(res,404,{error:'Not found.'});
    }finally{if(req.method==='POST')inFlight.delete(session.id);}
  }catch(e){json(res,400,{error:e.message, ...(e.debugId?{debugId:e.debugId}:{})});}
});
server.listen(port,'127.0.0.1',()=>console.log(`ScopePay running at ${appUrl} — PayPal SANDBOX only; local AI model ${MODEL}`));
